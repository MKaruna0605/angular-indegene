import { Component, OnChanges } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnChanges {

  slidervalue: any
  title = 'jyoti';
 
  ngOnChanges(changes: any) {
   let currentvalue = 1;
   this.slidervalue = 1;
  }
  tryagain() {

    //this.ngOnChanges
    this.slidervalue = 1;

  }

}
